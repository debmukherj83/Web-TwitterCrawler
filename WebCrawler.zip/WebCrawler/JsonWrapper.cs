﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebCrawler
{
    public class JsonWrapper
    {        
        public string uri { get; set; }
        public string headline { get; set; }
        public string thumbnail { get; set; }
        public string duration { get; set; }
        public string description { get; set; }
        public string layout { get; set; }
    }
}