﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using System.Web.UI.WebControls;
using System.Linq;
using System.Data;
using System.Text;
using Newtonsoft.Json.Linq;
using System.Security.Cryptography;
using LinqToTwitter;
using System.Configuration;

namespace WebCrawler
{
    public partial class HomePage : System.Web.UI.Page
    {
        public string query = "DebjyotiMukhe10";
        public string url = "https://api.twitter.com/1.1/statuses/user_timeline.json";

        private List<Status> currentTweets;
        static string soauth_token = ConfigurationManager.AppSettings["oauth_token"].ToString();
        static string soauth_token_secret = ConfigurationManager.AppSettings["oauth_token_secret"].ToString();
        static string soauth_consumer_key = ConfigurationManager.AppSettings["oauth_consumer_key"].ToString();
        static string soauth_consumer_secret = ConfigurationManager.AppSettings["oauth_consumer_secret"].ToString();

        protected void Page_Load(object sender, EventArgs e)
        {
           // findUserTwitter(url, query);
            string cnnNewsUrl = "http://edition.cnn.com/";
            GetNewLinks(cnnNewsUrl);
            GetTopNTwitterPosts(25,"Trump");                                                          
        }

        public void GetNewLinks(string url)
        {
            WebRequest myWebRequest;
            WebResponse myWebResponse;           
            myWebRequest = WebRequest.Create(url);
            myWebResponse = myWebRequest.GetResponse();

            Stream streamResponse = myWebResponse.GetResponseStream();
            StreamReader sreader = new StreamReader(streamResponse);
            string result = sreader.ReadToEnd();

            streamResponse.Close();
            sreader.Close();
            myWebResponse.Close();

            int start = result.IndexOf("articleList");
            int end = result.IndexOf("registryURL");
            string content1 = result.Substring(start - 2, end - start).Replace("{\"articleList\":","").Replace("]}", "]");

            List<JsonWrapper> newslist = JsonConvert.DeserializeObject<List<JsonWrapper>>(content1);
            List<JsonWrapper> newslistTrump = newslist.Where(s =>s.headline.Contains("Trump")).Take(25).ToList();

            grdNewsBulletin.DataSource = newslistTrump;
            grdNewsBulletin.DataBind();            
        }
        protected void grdNewsBulletin_ItemDataBound(object sender, DataGridItemEventArgs e)
        {
            if(e.Item.ItemType == ListItemType.Header)
            {

            }
            if(e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                string uri = ((JsonWrapper)e.Item.DataItem).uri.ToString();
                string headline = ((JsonWrapper)e.Item.DataItem).headline.ToString();

                HyperLink lnkName = (HyperLink)e.Item.FindControl("lnkName");
                lnkName.Text = headline;
                string url = "http://edition.cnn.com" + uri;
                lnkName.Attributes.Add("href", url);
                lnkName.Attributes.Add("title", "Click for details");
                lnkName.Attributes.Add("onclick", "javascript:OpenContent('" + url + "');return false;");
            }
        }

        public void findUserTwitter(string resource_url, string q)
        {

            // oauth application keys
            var oauth_token = soauth_token;
            var oauth_token_secret = soauth_token_secret;
            var oauth_consumer_key = soauth_consumer_key;
            var oauth_consumer_secret = soauth_consumer_secret;

            // oauth implementation details
            var oauth_version = "1.0";
            var oauth_signature_method = "HMAC-SHA1";

            // unique request details
            var oauth_nonce = Convert.ToBase64String(new ASCIIEncoding().GetBytes(DateTime.Now.Ticks.ToString()));
            var timeSpan = DateTime.UtcNow
                - new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            var oauth_timestamp = Convert.ToInt64(timeSpan.TotalSeconds).ToString();


            // create oauth signature
            var baseFormat = "oauth_consumer_key={0}&oauth_nonce={1}&oauth_signature_method={2}" +
                            "&oauth_timestamp={3}&oauth_token={4}&oauth_version={5}&q={6}";

            var baseString = string.Format(baseFormat,
                                        oauth_consumer_key,
                                        oauth_nonce,
                                        oauth_signature_method,
                                        oauth_timestamp,
                                        oauth_token,
                                        oauth_version,
                                        Uri.EscapeDataString(q)
                                        );

            baseString = string.Concat("GET&", Uri.EscapeDataString(resource_url), "&", Uri.EscapeDataString(baseString));

            var compositeKey = string.Concat(Uri.EscapeDataString(oauth_consumer_secret),
                                    "&", Uri.EscapeDataString(oauth_token_secret));

            string oauth_signature;
            using (HMACSHA1 hasher = new HMACSHA1(ASCIIEncoding.ASCII.GetBytes(compositeKey)))
            {
                oauth_signature = Convert.ToBase64String(
                    hasher.ComputeHash(ASCIIEncoding.ASCII.GetBytes(baseString)));
            }

            // create the request header
            var headerFormat = "OAuth oauth_nonce=\"{0}\", oauth_signature_method=\"{1}\", " +
                               "oauth_timestamp=\"{2}\", oauth_consumer_key=\"{3}\", " +
                               "oauth_token=\"{4}\", oauth_signature=\"{5}\", " +
                               "oauth_version=\"{6}\"";

            var authHeader = string.Format(headerFormat,
                                    Uri.EscapeDataString(oauth_nonce),
                                    Uri.EscapeDataString(oauth_signature_method),
                                    Uri.EscapeDataString(oauth_timestamp),
                                    Uri.EscapeDataString(oauth_consumer_key),
                                    Uri.EscapeDataString(oauth_token),
                                    Uri.EscapeDataString(oauth_signature),
                                    Uri.EscapeDataString(oauth_version)
                            );

            ServicePointManager.Expect100Continue = false;

            // make the request
            var postBody = "q=" + Uri.EscapeDataString(q);//
            resource_url += "?" + postBody;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(resource_url);
            request.Headers.Add("Authorization", authHeader);
            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            var response = (HttpWebResponse)request.GetResponse();
            var reader = new StreamReader(response.GetResponseStream());
            var objText = reader.ReadToEnd();
            //myDiv.InnerHtml = objText;/**/
            string html = "";
            try
            {
                JArray jsonDat = JArray.Parse(objText);
                for (int x = 0; x < jsonDat.Count(); x++)
                {
                    html += jsonDat[x]["text"].ToString() + "<br/>";
                    html += jsonDat[x]["created_at"].ToString() + "<br/>";
                }
                //myDiv.InnerHtml = html;
            }
            catch (Exception twit_error)
            {
                //myDiv.InnerHtml = html + twit_error.ToString();
            }
        }

        private void GetTopNTwitterPosts(int count, string userName)
        {
            var twitterContext = new TwitterContext(authorizer);

            var tweets = from tweet in twitterContext.Status
                         where tweet.Type == StatusType.Home &&  
                         tweet.TweetMode ==TweetMode.Extended &&                      
                         tweet.Count == count &&
                         tweet.User.Name.Contains(userName)
                         select tweet;

            currentTweets = tweets.ToList();            
            string txtTwt = "<ul>";

            currentTweets.ForEach(tweet =>
               txtTwt += "<li>" + tweet.User.Name.ToString() + " : " + ((tweet.FullText!= null && tweet.FullText.ToString() != "") ? tweet.FullText.ToString() : tweet.Text.ToString()) + "</li>");

            txtTwt += "</ul>";
            divTwt.InnerHtml = txtTwt;
            
        }

        private SingleUserAuthorizer authorizer =
         new SingleUserAuthorizer
         {
             CredentialStore =
            new SingleUserInMemoryCredentialStore
            {          
                ConsumerKey = soauth_consumer_key,
                    ConsumerSecret = soauth_consumer_secret,
                    AccessToken = soauth_token,
                    AccessTokenSecret = soauth_token_secret               
            }
         };        
    }
}